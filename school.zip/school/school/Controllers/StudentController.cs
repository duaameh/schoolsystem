﻿using Microsoft.AspNetCore.Mvc;
using school.Factory;
using school.Factory.Courses;
using school.Models;
using school.coursesStudentVm;
namespace school.Controllers
{
    public class StudentController : Controller
    {
        public readonly IstudentFactory _studentInterface;
        public readonly IcoursesFactorycs _coursesFactorycs;
        public StudentController(IstudentFactory istudentFactory, IcoursesFactorycs coursesFactorycs)
        {
            _studentInterface= istudentFactory;
            _coursesFactorycs= coursesFactorycs;

        }
        //list of student
        public IActionResult Index()
        {
            List<student>std=_studentInterface.GetAllStudentName();
            return View(std);
        }
        [HttpGet]
        public IActionResult create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(student students)
        {
            _studentInterface.create(students);
            List<student> std = _studentInterface.GetAllStudentName();
            return View("Index",std);
        }
        public IActionResult Delete(int id) //must be priary key
        {
            _studentInterface.Delete(id);
            List<student> std = _studentInterface.GetAllStudentName();
            return View("Index", std);
        }
        [HttpGet]
        public IActionResult Regester()
        {
            studentCoursesVm data = new studentCoursesVm();
            data.students= _studentInterface.GetAllStudentName();
            data.courses = _coursesFactorycs.GetAllcoursesName();
            return View(data);
        }
        [HttpPost]
        public IActionResult Regester(int studentId, int coursesId)
        {
            _studentInterface.Regester(studentId, coursesId);
            return RedirectToAction("Regester");
        }

    }
}
