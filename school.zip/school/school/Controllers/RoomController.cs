﻿using Microsoft.AspNetCore.Mvc;
using school.Factory;
using school.Models;

namespace school.Controllers
{
    public class RoomController : Controller
    {
        public readonly IRoomFactory _roomFactory;
        public RoomController(IRoomFactory roomFactory)
        {
                    _roomFactory = roomFactory;
        }
        public IActionResult Index()
        {
            List<Room >rooms=_roomFactory.GetAllRoomName();
            
            return View(rooms);
        }
        [HttpGet]
        public IActionResult create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(Room room)     
        {
            _roomFactory.create(room);
            List<Room> rooms = _roomFactory.GetAllRoomName();

            return View("index",rooms);
           
        }
        public IActionResult Delete(int id) //must be priary key
        { if (id > 0)
            {
                _roomFactory.Delete(id);
            }
                List<Room> rooms = _roomFactory.GetAllRoomName();

                return View("index", rooms);
            
           
        }
    }
}
