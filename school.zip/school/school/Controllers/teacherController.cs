﻿using Microsoft.AspNetCore.Mvc;
using school.Factory;
using school.Models;

namespace school.Controllers
{
    public class teacherController : Controller
    {
        public readonly IteacherFactory _iteacherFactory;
        public teacherController(IteacherFactory iteacherFactory)
        {
                _iteacherFactory = iteacherFactory;
        }
        
        public IActionResult Index()
        {
            List<teacher> teachers = _iteacherFactory.GetAllteacherName();
            return View(teachers);
        }
        [HttpGet]
        public IActionResult Create()
        {
            
            return View();
        }
        [HttpPost]
        public IActionResult Create(teacher teachers)
        {
            _iteacherFactory.create(teachers);
            List<teacher> allTeachers = _iteacherFactory.GetAllteacherName(); // Retrieve all teachers
            return View("Index", allTeachers); // Pass the list of teachers to the Index view
        }

        public IActionResult delete(int id)
        {
            _iteacherFactory.Delete(id);
            List<teacher> allTeachers = _iteacherFactory.GetAllteacherName(); // Retrieve all teachers
            return View("Index", allTeachers);
        }


    }
}
