﻿using Microsoft.AspNetCore.Mvc;
using school.Factory;
using school.Factory.Courses;
using school.Models;

namespace school.Controllers
{
    public class coursesController : Controller
    {
        readonly IcoursesFactorycs _coursesFactorycs;
        public readonly IteacherFactory _iteacherFactory;

        public coursesController(IcoursesFactorycs _coursesFactorycs, IteacherFactory iteacherFactory)
        {
            this._coursesFactorycs = _coursesFactorycs;
            this._iteacherFactory=iteacherFactory;
            
        }
        public IActionResult Index()
        {
            List<courses> courses =_coursesFactorycs.GetAllcoursesName();
           
            return View(courses);
        }
        [HttpGet]
        public IActionResult create()
        {
            List<teacher> teachers = _iteacherFactory.GetAllteacherName();
            return View(teachers);
        }
        [HttpPost]
        public IActionResult create(courses courses)
        {
            _coursesFactorycs.create(courses);
            List<courses> course = _coursesFactorycs.GetAllcoursesName();
            return View("Index",course);
        }
        public IActionResult Delete(String Rcourses) //must be priary key
        {
            _coursesFactorycs.Delete(Rcourses);
            List<courses> course = _coursesFactorycs.GetAllcoursesName();
            return View("Index", course);
        }
    }
}
