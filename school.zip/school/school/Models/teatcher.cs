﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace school.Models
{
    public class teacher
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int teacherId { set; get; }
        [MinLength(3)]
        [MaxLength(30)]
        public String teacherName { set; get; }
        [Range(22, 55)]
        public int teacherAge { set; get; }
    }
}
