﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace school.Models
{
    public class student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int studentId { set; get; }

        [MinLength(3)]
        [MaxLength(30)]
        public String studentName { set; get; }
        [Range(5,18)]
        public int studentAge{ set; get; }
        public bool isActive { set; get; }

    }
}
