﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace school.Models
{
    public class courses
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int coursesId { set; get; }
        [MinLength(3)]
        [MaxLength(70)]
        public String Rcourses { set; get; }
        [Range(0, 55)]
        public int teacherId { set; get; }
        [ForeignKey("teacherId")]
        public virtual teacher teacher { set; get; }
        [Range(0, 55)]
        public int coursesCapcity { set; get; }
    }
}
