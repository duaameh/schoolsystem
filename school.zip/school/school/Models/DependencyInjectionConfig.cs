﻿using Microsoft.EntityFrameworkCore;
using school.context;

namespace school.Models
{
    public class DependencyInjectionConfig
    {
        public static void Configure(IServiceCollection services)
        {
            
        }
    }
}
