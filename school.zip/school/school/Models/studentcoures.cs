﻿using System.ComponentModel.DataAnnotations.Schema;

namespace school.Models
{
    public class studentcoures
    {
        public int studentcouresId { set; get; }
        public int studentId { set; get; }
        [ForeignKey("studentId")]
        public student student { set; get; }
        public int coursesId {  set; get; }
        [ForeignKey("coursesId")]

        public courses courses { set; get; }

}
}
