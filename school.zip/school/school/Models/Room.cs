﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace school.Models
{
    public class Room 
    { 
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RoomId { set; get; }
        [MinLength(3)]
        [MaxLength(30)]
        public string RoomName{ set; get; }

    }
}
