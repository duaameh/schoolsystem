﻿using school.Models;

namespace school.coursesStudentVm
{
    public class studentCoursesVm
    {
       public List<student> students{get; set;}
        public List<courses> courses { get; set;}
    }
}
