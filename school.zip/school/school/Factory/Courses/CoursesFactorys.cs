﻿using school.context;
using school.Models;

namespace school.Factory.Courses
{
    public class CoursesFactorys : IcoursesFactorycs
    {
        private readonly MyContext _context;
        public CoursesFactorys(MyContext context)
        {
                _context = context;
        }
        public void create(courses courses)
        {
            _context.Courses.Add(courses);
            _context.SaveChanges();

        }

        public void Delete(string Rcourses)
        {
            courses courses = (from objst in _context.Courses
                              where objst.Rcourses ==Rcourses
                              select objst).FirstOrDefault();
            _context.Courses.Remove(courses);
            _context.SaveChanges();
        }

        public List<courses> GetAllcoursesName()
        {
            try
            {
                List<courses> courses1 = (from objcourses in _context.Courses select objcourses).ToList();
                return courses1;
            }
            catch 
            {
                throw;
            }
        }
    }
}
