﻿using school.Models;

namespace school.Factory.Courses
{
    public interface IcoursesFactorycs
    {
        public List<courses> GetAllcoursesName();
        public void create(courses courses);
        public void Delete(String Rcourses);
    }
}
