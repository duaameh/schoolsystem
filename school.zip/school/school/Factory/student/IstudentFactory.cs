﻿using school.Models;

namespace school.Factory
{
    public interface IstudentFactory
    {
        public List<student> GetAllStudentName();
        public void create(student student);
        public void Delete(int id);
        public void Regester(int studentId, int couresId);
    }
}
