﻿using Microsoft.EntityFrameworkCore;
using school.context;
using school.Models;

namespace school.Factory
{
    public class StudentFactory : IstudentFactory
    {
        readonly MyContext _context;
        public StudentFactory(MyContext myContext)
        {
            _context = myContext;

        }
        public List<student> GetAllStudentName()
        { //temp useing to transfer data between two action
            try
            {
                List<student> students = (from objt in _context.students select objt).ToList();//objt runtime 
                return students;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void create(student student)
        {/*
          onther way 
              student std = new student();
            std.studentName = " ";
            std.studentId = 111;
            std.isActive = true;
           
          */
            _context.students.Add(student);
            _context.SaveChanges();

        }

        public void Delete(int id)
        {
            
            student student = (from objst in _context.students
                               where objst.studentId == id
                               select objst).FirstOrDefault();
            /*
             to specidic attrubite 
            student student = (from objst in _myContext.students
                             where objst.studentId==id
                             select objst.studentId ).FirstOrDefault();
             */
            if(student != null) {
                _context.students.Remove(student);
                _context.SaveChanges();
            }
            ;

        }


        public void Regester(int studentId, int coursesId)
        {
            //  _myContext.Studentcoures.Add(new studentcoures { couresId=couresId ,studentId=studentId});
            school.Models.studentcoures std = new school.Models.studentcoures();
            std.studentId = studentId;
            std.coursesId= coursesId;
            _context.Studentcoures.Add(std);
            
            _context.SaveChanges();

        }
    }
}
