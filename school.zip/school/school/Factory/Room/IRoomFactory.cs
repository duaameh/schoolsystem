﻿namespace school.Factory
{
    public interface IRoomFactory
    {
        public List<school.Models.Room> GetAllRoomName();
        public void create(school.Models.Room room);
        public void Delete( int id);

    }
}
