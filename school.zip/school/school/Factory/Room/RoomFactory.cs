﻿
using school.context;
using school.Models;

namespace school.Factory
{
    public class RoomFactory : IRoomFactory
    {
        readonly MyContext _context;
        public RoomFactory(MyContext context)
        {
            _context = context;
        }
        
        void IRoomFactory.create(Room room)
        {

            _context.Rooms.Add(room);
            _context.SaveChanges();

        }
        void IRoomFactory.Delete(int id)
        {
            Room room = (from obj in _context.Rooms
                               where obj.RoomId== id
                               select obj).FirstOrDefault();
            if(room != null ) {
                _context.Rooms.Remove(room);
                _context.SaveChanges();
            }
            
        }

        List<Room> IRoomFactory.GetAllRoomName()
        {
            try
            {
                List<school.Models.Room> rooms = (from objt in _context.Rooms select objt).ToList();//objt runtime 
                return rooms;
            }
            catch 
            {
                throw;
            }
        }
    }
}
