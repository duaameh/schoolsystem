﻿using school.Models;

namespace school.Factory
{
    public interface IteacherFactory
    {
        public List<teacher> GetAllteacherName();
        public void create(teacher teacher);
        public void Delete(int id);
    }

}
