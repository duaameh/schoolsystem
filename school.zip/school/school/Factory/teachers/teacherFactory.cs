﻿using school.context;
using school.Models;

namespace school.Factory
{
    public class teacherFactory : IteacherFactory
    {
        readonly MyContext _context;
        public teacherFactory(MyContext myContext)
        {

            _context = myContext;

        }
        public void create(teacher teacher)
        {
            _context.teacher.Add(teacher);
            _context.SaveChanges();

        }

        public void Delete(int id)
        { if(id != 0) 
            {
                var std = (from objtech in _context.teacher where objtech.teacherId == id select objtech).FirstOrDefault();
              if(std != null)
                _context.Remove(std);
                _context.SaveChanges();
            }
            
        }

        public List<teacher> GetAllteacherName()
        {
            try
            {
                List<teacher> teachers = (from objtech in _context.teacher select objtech).ToList();
                return teachers;
            }
            catch { throw; }
        }
    }
}
