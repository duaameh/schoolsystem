﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.ComponentModel.DataAnnotations;
using school.Models;

namespace school.context
{
    public class MyContext:DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options) { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: true);
            IConfigurationRoot configurationRoot = builder.Build();
            var constring = configurationRoot.GetConnectionString("my connection");
            optionsBuilder.UseSqlServer(constring);


        }
        public DbSet<teacher> teacher { get; set; }
        public DbSet<studentcoures> Studentcoures{ get; set; }
        public DbSet<student>students  { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<courses> Courses { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
